-- Habilita extensiones requeridas (en Supabase vienen por defecto)
-- create extension if not exists "pgcrypto";

create table if not exists companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text unique,
  plan text check (plan in ('free','pro','enterprise')) default 'free',
  created_at timestamptz default now()
);

create table if not exists candidates (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique,
  exp text,
  education text,
  skills text[],
  province text,
  -- Datos privados en JSONB para bloquear por defecto
  name text,
  email text,
  phone text,
  created_at timestamptz default now()
);

create table if not exists jobs (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies(id) on delete cascade,
  title text not null,
  description text,
  city text default 'Barcelona',
  province text default 'Barcelona',
  category text default 'Metal',
  status text check (status in ('active','paused','closed')) default 'active',
  published_at timestamptz default now()
);

create table if not exists offers (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies(id) on delete cascade,
  candidate_id uuid references candidates(id) on delete cascade,
  job_id uuid references jobs(id) on delete set null,
  status text check (status in ('pending','accepted','rejected')) default 'pending',
  unlocked boolean default false,
  created_at timestamptz default now()
);

create table if not exists reviews (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references companies(id) on delete cascade,
  user_id uuid,
  stars int check (stars between 1 and 5) not null,
  text text not null,
  credibility_score int default 0,
  votes_count int default 0,
  created_at timestamptz default now(),
  unique (company_id, user_id)
);

create table if not exists review_votes (
  id uuid primary key default gen_random_uuid(),
  review_id uuid references reviews(id) on delete cascade,
  user_id uuid,
  value smallint check (value in (-1,1)) not null,
  created_at timestamptz default now(),
  unique (review_id, user_id)
);

-- Función para votar veracidad (simplificada)
create or replace function vote_review(p_review_id uuid, p_value smallint)
returns void language plpgsql as $$
begin
  update reviews
  set credibility_score = credibility_score + p_value,
      votes_count = votes_count + 1
  where id = p_review_id;
end;
$$;
