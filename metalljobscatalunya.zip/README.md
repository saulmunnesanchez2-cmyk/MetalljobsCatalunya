# MetallJobsCatalunya

Empleo del **sector metal** en Catalunya. Candidatos gratis y anónimos hasta aceptar oferta. Empresas con **plan Pro** para publicar y ver contactos.

## Puesta en marcha

```bash
npm install
cp .env.example .env.local  # Rellena las claves de Supabase y Stripe (opcional)
npm run dev
```

## Despliegue (Vercel)

1. Sube este repo a GitHub.
2. En Vercel: Import Project → añade variables de entorno de `.env.example`.
3. Deploy.

## Supabase (schema sugerido)

Consulta `supabase/schema.sql` para tablas, RLS y vista `candidate_contacts` que sólo revela datos privados tras aceptar una oferta.
```

