import { useState } from 'react';

export default function ReviewForm({ companyId, onSubmitted }){
  const [stars, setStars] = useState(5);
  const [text, setText] = useState('');

  const submit = async () => {
    const res = await fetch('/api/reviews', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ companyId, stars, text })
    });
    if(res.ok){ setText(''); onSubmitted?.(); }
    else alert('No se pudo enviar la opinión');
  };

  return (
    <div className="card space-y-2">
      <h4 className="font-semibold">Escribir opinión (anónima)</h4>
      <select className="border rounded-xl px-3 py-2" value={stars} onChange={e=>setStars(Number(e.target.value))}>
        {[1,2,3,4,5].map(s=><option key={s} value={s}>{s} ⭐</option>)}
      </select>
      <textarea className="border rounded-xl w-full p-2" rows={3} placeholder="Tu experiencia..." value={text} onChange={e=>setText(e.target.value)} />
      <button onClick={submit} className="btn">Enviar</button>
    </div>
  );
}
