import Link from 'next/link';
import { MapPin, Building2 } from 'lucide-react';

export default function JobCard({ job }){
  return (
    <article className="card space-y-2">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-lg">{job.title}</h3>
        <span className="badge">{job.category || 'Metal'}</span>
      </div>
      <div className="text-sm text-gray-600">
        <Building2 className="inline w-4 h-4 mr-1" /> Empresa #{(job.company_id || '').toString().slice(0,4)}
        <span className="mx-1">•</span>
        <MapPin className="inline w-4 h-4 mr-1" /> {job.city} ({job.province})
      </div>
      <p className="text-sm text-gray-700">{(job.description || '').slice(0,160)}...</p>
      <Link href={`/job/${job.id}`} className="underline text-sm">Ver oferta</Link>
    </article>
  );
}
