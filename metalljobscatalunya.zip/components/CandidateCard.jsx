export default function CandidateCard({ candidate }){
  return (
    <article className="card space-y-2">
      <h3 className="font-semibold">Candidato/a del metal</h3>
      <p className="text-sm text-gray-700">{candidate.exp || 'Experiencia no indicada'}</p>
      <div className="text-xs text-gray-600">Habilidades: {(candidate.skills || []).join(', ')}</div>
      <div className="text-xs text-gray-500">Provincia: {candidate.province}</div>
      <div className="text-xs text-amber-700">
        Datos personales ocultos hasta aceptar oferta.
      </div>
    </article>
  );
}
