import Link from 'next/link';
import { Hammer } from 'lucide-react';

export default function Header(){
  return (
    <header className="bg-white border-b">
      <div className="container py-3 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 font-semibold">
          <Hammer className="w-5 h-5" />
          MetallJobsCatalunya
        </Link>
        <nav className="flex items-center gap-3">
          <Link href="/dashboard" className="text-sm">Panel</Link>
          <Link href="/login" className="btn btn-secondary text-sm">Entrar</Link>
        </nav>
      </div>
    </header>
  );
}
