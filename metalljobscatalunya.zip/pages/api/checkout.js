export default async function handler(req, res){
  // Stub: simula un checkout correcto y upgrade del plan
  if(req.method === 'GET'){
    return res.status(200).send(`<html><body style="font-family: sans-serif;">
<h1>Checkout Pro (simulado)</h1>
<p>Pago procesado. Tu empresa ahora es <strong>Pro</strong>.</p>
<p><a href="/dashboard">Volver al panel</a></p>
</body></html>`);
  }
  return res.status(405).end();
}
