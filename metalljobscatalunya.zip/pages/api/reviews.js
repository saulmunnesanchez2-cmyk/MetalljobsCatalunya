import { supabase } from '../../lib/supabaseClient';

export default async function handler(req, res){
  if(req.method === 'POST'){
    const { companyId, stars, text } = req.body || {};
    const { error } = await supabase.from('reviews').insert({
      company_id: companyId, stars: Number(stars)||5, text: text||''
    });
    if(error) return res.status(400).json({ error: error.message });
    return res.status(200).json({ ok:true });
  }
  if(req.method === 'PATCH'){
    const { reviewId, value } = req.body || {};
    const { error } = await supabase.rpc('vote_review', { p_review_id: reviewId, p_value: value });
    if(error) return res.status(400).json({ error: error.message });
    return res.status(200).json({ ok:true });
  }
  return res.status(405).end();
}
