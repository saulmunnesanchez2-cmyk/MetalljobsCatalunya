import { supabase } from '../../lib/supabaseClient';

export default async function handler(req, res){
  if(req.method !== 'POST') return res.status(405).end();
  const { offerId, candidateId, accepted } = req.body || {};
  if(!offerId || !candidateId) return res.status(400).json({ error:'Faltan datos' });

  if(accepted){
    await supabase.from('offers').update({ status:'accepted', unlocked:true }).eq('id', offerId);
    // En lugar de exponer columnas sensibles directamente, en producción deberías usar una VIEW con RLS.
    const { data: c } = await supabase.from('candidates')
      .select('name,email,phone').eq('id', candidateId).single();
    return res.status(200).json({ unlocked:true, candidate:c });
  }
  return res.status(200).json({ unlocked:false });
}
