import { supabase } from '../../lib/supabaseClient';

export default async function handler(req, res){
  try{
    const { action } = req.body || {};
    if(req.method === 'POST'){
      if(action === 'create'){
        // Aquí deberías verificar plan Pro del usuario/empresa.
        const title = req.body.title || 'Oferta del metal';
        const { data, error } = await supabase.from('jobs').insert({
          title, description: 'Descripción pendiente', city:'Barcelona', province:'Barcelona', category:'Metal', status:'active'
        }).select().single();
        if(error) return res.status(400).json({ error: error.message });
        return res.status(200).json({ ok: true, job: data });
      }
      if(action === 'apply'){
        // En producción: vincular con candidate_id de auth.user
        return res.status(200).json({ ok: true });
      }
    }
    if(req.method === 'GET'){
      const { data, error } = await supabase.from('jobs').select('*').eq('status','active');
      if(error) return res.status(400).json({ error: error.message });
      return res.status(200).json(data);
    }
    return res.status(405).end();
  }catch(e){
    return res.status(500).json({ error: 'Server error' });
  }
}
