import Header from '../../components/Header';
import { useRouter } from 'next/router';
import { useState, useEffect } from 'react';
import { supabase } from '../../lib/supabaseClient';

export default function JobDetail(){
  const router = useRouter();
  const { id } = router.query;
  const [job, setJob] = useState(null);

  useEffect(()=>{
    if(!id) return;
    (async()=>{
      const { data } = await supabase.from('jobs').select('*').eq('id', id).single();
      setJob(data);
    })();
  },[id]);

  const apply = async () => {
    const res = await fetch('/api/jobs', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ action:'apply', jobId:id })
    });
    if(res.ok) alert('Candidatura enviada de forma anónima.');
    else alert('Error enviando candidatura');
  };

  if(!job) return <div><Header /><main className="container py-6">Cargando...</main></div>;
  return (
    <div>
      <Header />
      <main className="container py-6 space-y-3">
        <h1 className="text-2xl font-bold">{job.title}</h1>
        <div className="text-sm text-gray-600">{job.city} ({job.province}) · {job.category}</div>
        <p className="whitespace-pre-wrap">{job.description}</p>
        <button className="btn" onClick={apply}>Aplicar</button>
      </main>
    </div>
  );
}
