import Header from '../components/Header';
import { useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export default function Login(){
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('candidate');

  const signIn = async () => {
    const { error } = await supabase.auth.signInWithOtp({ email });
    if(error) alert('Error: '+error.message);
    else alert('Revisa tu email para entrar.');
  };

  return (
    <div>
      <Header />
      <main className="container py-6 space-y-3">
        <h1 className="text-2xl font-bold">Entrar / Registrarse</h1>
        <input className="border rounded-xl px-3 py-2 w-80" placeholder="tu@email" value={email} onChange={e=>setEmail(e.target.value)} />
        <select className="border rounded-xl px-3 py-2 w-80" value={role} onChange={e=>setRole(e.target.value)}>
          <option value="candidate">Candidato/a</option>
          <option value="company">Empresa</option>
        </select>
        <button className="btn" onClick={signIn}>Continuar</button>
        <p className="text-xs text-gray-500">Tu rol se guardará al completar el perfil en el panel.</p>
      </main>
    </div>
  );
}
