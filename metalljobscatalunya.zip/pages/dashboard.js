import Header from '../components/Header';
import CandidateCard from '../components/CandidateCard';
import ReviewForm from '../components/ReviewForm';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabaseClient';

export default function Dashboard(){
  const [tab, setTab] = useState('candidate');
  const [candidates, setCandidates] = useState([]);
  const [jobs, setJobs] = useState([]);

  useEffect(()=>{
    (async()=>{
      const { data: cds } = await supabase.from('candidates').select('id,exp,skills,province');
      setCandidates(cds || []);
      const { data: j } = await supabase.from('jobs').select('*').eq('status','active');
      setJobs(j || []);
    })();
  },[]);

  const createJob = async () => {
    const title = prompt('Título de la oferta:');
    if(!title) return;
    const res = await fetch('/api/jobs', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ action:'create', title })
    });
    if(res.ok) location.reload();
    else alert('Necesitas plan Pro o sesión de empresa.');
  };

  return (
    <div>
      <Header />
      <main className="container py-6 space-y-5">
        <div className="card flex gap-2">
          <button onClick={()=>setTab('candidate')} className={`btn-secondary ${tab==='candidate'?'!bg-black !text-white':''}`}>Candidato</button>
          <button onClick={()=>setTab('company')} className={`btn-secondary ${tab==='company'?'!bg-black !text-white':''}`}>Empresa</button>
        </div>

        {tab==='candidate' && (
          <section className="grid md:grid-cols-2 gap-4">
            {candidates.map(c => <CandidateCard key={c.id} candidate={c} />)}
          </section>
        )}

        {tab==='company' && (
          <section className="space-y-3">
            <div className="card">
              <h2 className="font-semibold mb-2">Ofertas activas</h2>
              <ul className="list-disc pl-5">
                {jobs.map(j => <li key={j.id}>{j.title}</li>)}
              </ul>
              <div className="mt-3 flex gap-2">
                <button className="btn" onClick={createJob}>Crear oferta (requiere Pro)</button>
                <a className="btn-secondary" href="/api/checkout">Mejorar a Pro</a>
              </div>
            </div>

            <div className="card">
              <h2 className="font-semibold">Opiniones sobre tu empresa</h2>
              <p className="text-sm text-gray-600">Los usuarios pueden dejar 1 opinión anónima y la comunidad valora su veracidad.</p>
              <ReviewForm companyId={'demo-company'} onSubmitted={()=>alert('¡Gracias!')} />
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
