import Header from '../components/Header';
import JobCard from '../components/JobCard';
import { supabase } from '../lib/supabaseClient';

export default function Home({ jobs }){
  return (
    <div>
      <Header />
      <main className="container py-6 space-y-4">
        <h1 className="text-2xl font-bold">Ofertas del metal en Catalunya</h1>
        <p className="text-gray-600">Perfiles anónimos hasta aceptar oferta. Empresas con plan Pro para contactos.</p>
        <section className="grid md:grid-cols-2 gap-4">
          {(jobs || []).map(j => <JobCard key={j.id} job={j} />)}
        </section>
      </main>
    </div>
  );
}

export async function getServerSideProps(){
  try{
    const { data } = await supabase.from('jobs').select('*').eq('status','active');
    return { props: { jobs: data || [] } };
  }catch(e){
    return { props: { jobs: [] } };
  }
}
